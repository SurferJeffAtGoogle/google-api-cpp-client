var searchData=
[
  ['launchinfo',['LaunchInfo',['../classgoogle__calendar__api_1_1LaunchInfo.html#a3a0ba5c557e88adb6280b3e717cefd24',1,'google_calendar_api::LaunchInfo::LaunchInfo(const Json::Value &amp;storage)'],['../classgoogle__calendar__api_1_1LaunchInfo.html#a26ff94e53ef87a8c168f49b03dce8591',1,'google_calendar_api::LaunchInfo::LaunchInfo(Json::Value *storage)']]],
  ['link',['Link',['../classgoogle__calendar__api_1_1Link.html#aa47598a423f6967e503993846aee26f7',1,'google_calendar_api::Link::Link(const Json::Value &amp;storage)'],['../classgoogle__calendar__api_1_1Link.html#a072946add7a2d0b0e2bf7034705f5fdc',1,'google_calendar_api::Link::Link(Json::Value *storage)']]]
];
