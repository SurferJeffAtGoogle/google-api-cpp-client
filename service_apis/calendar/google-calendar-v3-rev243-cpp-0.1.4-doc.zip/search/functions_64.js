var searchData=
[
  ['deeplinkdata',['DeepLinkData',['../classgoogle__calendar__api_1_1DeepLinkData.html#a10728e6a4fe21a44fdf19e8f9104bb54',1,'google_calendar_api::DeepLinkData::DeepLinkData(const Json::Value &amp;storage)'],['../classgoogle__calendar__api_1_1DeepLinkData.html#a46a6069a5296fc4e86d1e3fc5d92037a',1,'google_calendar_api::DeepLinkData::DeepLinkData(Json::Value *storage)']]],
  ['displayinfo',['DisplayInfo',['../classgoogle__calendar__api_1_1DisplayInfo.html#a8fb3b8525d27bc274a35d2dc708ea2dc',1,'google_calendar_api::DisplayInfo::DisplayInfo(const Json::Value &amp;storage)'],['../classgoogle__calendar__api_1_1DisplayInfo.html#a4922f8447d8cbe69b031ca5f1369c6c8',1,'google_calendar_api::DisplayInfo::DisplayInfo(Json::Value *storage)']]]
];
